(self.webpackChunk_N_E=self.webpackChunk_N_E||[]).push([[846],{2984:function(e,r,n){Promise.resolve().then(n.bind(n,3545))},3545:function(e,r,n){"use strict";n.r(r),n.d(r,{default:function(){return Page}});var t=n(7437);function Page(){return(0,t.jsx)("div",{children:"Here you can download your invoices"})}},622:function(e,r,n){"use strict";/**
 * @license React
 * react-jsx-runtime.production.min.js
 *
 * Copyright (c) Meta Platforms, Inc. and affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */var t=n(2265),o=Symbol.for("react.element"),u=Symbol.for("react.fragment"),f=Object.prototype.hasOwnProperty,i=t.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED.ReactCurrentOwner,s={key:!0,ref:!0,__self:!0,__source:!0};function q(e,r,n){var t,u={},c=null,_=null;for(t in void 0!==n&&(c=""+n),void 0!==r.key&&(c=""+r.key),void 0!==r.ref&&(_=r.ref),r)f.call(r,t)&&!s.hasOwnProperty(t)&&(u[t]=r[t]);if(e&&e.defaultProps)for(t in r=e.defaultProps)void 0===u[t]&&(u[t]=r[t]);return{$$typeof:o,type:e,key:c,ref:_,props:u,_owner:i.current}}r.Fragment=u,r.jsx=q,r.jsxs=q},7437:function(e,r,n){"use strict";e.exports=n(622)}},function(e){e.O(0,[971,472,744],function(){return e(e.s=2984)}),_N_E=e.O()}]);